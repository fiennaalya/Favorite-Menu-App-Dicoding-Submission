package com.example.finalproject

data class Daftar(
    var name: String = "",
    var detail: String = "",
    var photo: Int = 0,
    var detail_harga : String = "",
    var detail_rating : String = ""


)